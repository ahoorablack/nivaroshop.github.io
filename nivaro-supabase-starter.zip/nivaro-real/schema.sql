-- NIVARO Supabase schema. Run the whole file in Supabase > SQL Editor > New query.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  full_name text not null default '',
  role text not null default 'customer' check (role in ('customer','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.projects (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 120),
  project_type text not null default 'سایر',
  description text not null check (char_length(description) between 1 and 5000),
  budget text,
  status text not null default 'new' check (status in ('new','in_progress','waiting','done','cancelled')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.tickets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  subject text not null check (char_length(subject) between 1 and 150),
  message text not null check (char_length(message) between 1 and 5000),
  status text not null default 'open' check (status in ('open','in_progress','answered','closed')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.ticket_replies (
  id uuid primary key default gen_random_uuid(),
  ticket_id uuid not null references public.tickets(id) on delete cascade,
  admin_id uuid not null references public.profiles(id) on delete cascade,
  message text not null check (char_length(message) between 1 and 5000),
  created_at timestamptz not null default now()
);

-- Automatically create a customer profile when a user signs up.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (id, email, full_name, role)
  values (new.id, new.email, coalesce(new.raw_user_meta_data ->> 'full_name',''), 'customer')
  on conflict (id) do nothing;
  return new;
end;
$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Security helper reads the role from profiles; users cannot update their own role.
create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.profiles p where p.id = (select auth.uid()) and p.role = 'admin');
$$;
revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to authenticated;

alter table public.profiles enable row level security;
alter table public.projects enable row level security;
alter table public.tickets enable row level security;
alter table public.ticket_replies enable row level security;

-- Profiles: user can read own profile; admin can read all. No client can update role.
drop policy if exists "read own or admin profiles" on public.profiles;
create policy "read own or admin profiles" on public.profiles for select to authenticated using (id = (select auth.uid()) or public.is_admin());
drop policy if exists "update own name only" on public.profiles;
create policy "update own name only" on public.profiles for update to authenticated using (id = (select auth.uid())) with check (id = (select auth.uid()) and role = 'customer');
-- Admin promotion is done by the project owner from SQL Editor, never from the public site.

drop policy if exists "customers create own projects" on public.projects;
create policy "customers create own projects" on public.projects for insert to authenticated with check (user_id = (select auth.uid()));
drop policy if exists "read own projects or admin all" on public.projects;
create policy "read own projects or admin all" on public.projects for select to authenticated using (user_id = (select auth.uid()) or public.is_admin());
drop policy if exists "admin update projects" on public.projects;
create policy "admin update projects" on public.projects for update to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "customers create own tickets" on public.tickets;
create policy "customers create own tickets" on public.tickets for insert to authenticated with check (user_id = (select auth.uid()));
drop policy if exists "read own tickets or admin all" on public.tickets;
create policy "read own tickets or admin all" on public.tickets for select to authenticated using (user_id = (select auth.uid()) or public.is_admin());
drop policy if exists "admin update tickets" on public.tickets;
create policy "admin update tickets" on public.tickets for update to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "read own ticket replies or admin" on public.ticket_replies;
create policy "read own ticket replies or admin" on public.ticket_replies for select to authenticated using (public.is_admin() or exists (select 1 from public.tickets t where t.id = ticket_id and t.user_id = (select auth.uid())));
drop policy if exists "admin creates replies" on public.ticket_replies;
create policy "admin creates replies" on public.ticket_replies for insert to authenticated with check (public.is_admin() and admin_id = (select auth.uid()));

-- No delete policies are granted to customers. RLS blocks access by default.
