NIVARO WEB STUDIO — Website starter
1) Extract this ZIP.
2) Open index.html in a browser to preview.
3) To publish on Cloudflare Pages: create a GitHub repository, upload index.html to the repository root, then in Cloudflare Pages import that repository.
This is a static portfolio/agency website. Contact form is a demo and does not send/store messages. Replace sample content and contact details before using it commercially.
